@echo off
setlocal
cd /d "%~dp0"
if exist "runtime\python.exe" (
  "runtime\python.exe" -I -B iniciar.py
) else (
  py -3 iniciar.py
)
pause
