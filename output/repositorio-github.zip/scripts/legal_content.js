/** Public draft copy reflects the current presentation; no fictional operator data. */

export function legal_page(title, intro, sections) {
  const navigation = sections
    .map(([key, label]) => `<a href="#${key}">${label}</a>`)
    .join('');
  const article = sections
    .map(
      ([key, label, body]) => `<section id="${key}"><h2>${label}</h2>${body}</section>`,
    )
    .join('');
  return `<div class="container"><header class="legal-intro"><span class="eyebrow">Información y transparencia</span><h1>${title}</h1><p>${intro}</p><div class="legal-version">Versión de presentación · 26 de octubre de 2026</div><div class="legal-state"><strong>Borrador para la etapa de presentación</strong><p>Las inscripciones y los cobros no están habilitados. Antes de ofrecer el servicio se completarán los datos del responsable, el canal de contacto y las condiciones comerciales. Este texto no representa una certificación de cumplimiento.</p></div></header><div class="legal-layout section" style="padding-top:20px"><nav class="legal-nav" aria-label="Índice de esta página">${navigation}</nav><article class="legal-article">${article}<a class="text-link" href="../index.html"> Volver al inicio</a></article></div></div>`;
}

export const terms_content = legal_page(
  'Términos y condiciones',
  'Conocé el alcance de esta presentación y cómo se prevé organizar la futura propuesta de estudio.',
  [
    [
      'proyecto',
      '01. Identidad y alcance',
      `<p>Método Judicial es el nombre provisional de una propuesta de preparación independiente para estudiantes del concurso de ingreso al Poder Judicial de Mendoza. No es un organismo público, no representa al Poder Judicial y no cuenta con un aval institucional anunciado en este sitio.</p><p>Esta versión permite conocer el método, el temario y los recursos previstos. No permite contratar el curso, efectuar pagos ni crear cuentas públicas. El equipo puede probar ejercicios introductorios mediante una código local habilitado manualmente. Los datos de identificación del prestador y su canal de contacto se incorporarán antes de abrir la contratación.</p>`,
    ],
    [
      'propuesta',
      '02. Contenidos y etapas',
      `<p>La primera etapa proyecta cinco bibliotecas, cada una con libro, resumen, cuadro comparativo y esquema; una evaluación de 20 preguntas por módulo; un camino de logros simbólicos y un examen final de 50 preguntas sobre los cinco módulos.</p><p>Los resúmenes, cuadros, esquemas y exámenes están en preparación. Comprensión lectora y mecanografía corresponden a etapas posteriores, sin fecha de disponibilidad confirmada. Su mención no significa que estén disponibles ni que se incluyan automáticamente en una futura compra.</p>`,
    ],
    [
      'acceso',
      '03. Inscripción, pago y acceso',
      `<p>Cuando se habilite el servicio, antes del pago se informarán el precio total, los medios de pago, los contenidos incluidos, el período de acceso, los requisitos técnicos y las condiciones de soporte. No se establecen en esta presentación valores, plazos ni beneficios que aún no fueron definidos.</p><p>El acceso previsto es personal y se habilitará después de la verificación del pago por el equipo. La código local de prueba permite utilizar ejercicios breves, sin acceso a material comercial. La autenticación de esta prueba se valida en el servidor y requiere una cuenta habilitada. Las reglas de evaluación y los intentos se informarán antes de habilitar los exámenes.</p>`,
    ],
    [
      'uso',
      '04. Uso de los recursos',
      `<p>Los recursos propios que se entreguen estarán destinados al estudio personal conforme al alcance de la contratación. No se autoriza su reventa, redistribución ni publicación sin permiso de quien sea titular de los derechos.</p><p>Los documentos y signos de terceros conservan su autoría y régimen de uso. La referencia al material del concurso no atribuye su autoría al curso. Los enlaces a páginas oficiales permiten consultar la fuente y no significan patrocinio, asociación ni aprobación del proyecto.</p>`,
    ],
    [
      'evaluacion',
      '05. Preparación y resultados',
      `<p>La propuesta tiene finalidad educativa. El estudio, las evaluaciones y los logros del campus no equivalen a una certificación oficial ni garantizan aprobación, puntaje, puesto o ingreso al Poder Judicial.</p><p>La convocatoria, los requisitos, las fechas y las decisiones del concurso se consultan en el <a href="https://jusmendoza.gob.ar/concurso-ingreso-administrativo-2026/" target="_blank" rel="noopener noreferrer">sitio oficial del concurso 2026 </a>. Las novedades del curso no reemplazan esas comunicaciones.</p>`,
    ],
    [
      'derechos',
      '06. Derechos del estudiante',
      `<p>Las condiciones que se publiquen para la contratación deberán preservar los derechos que correspondan según la normativa aplicable, incluidos información, trato digno y reclamo. Este borrador no contiene una renuncia de derechos ni una prohibición general de devoluciones.</p><p>Antes de habilitar ventas se informarán y se instrumentarán los canales de consulta, reclamo, cancelación y ejercicio del derecho de arrepentimiento cuando corresponda. En esta presentación no se procesan compras ni solicitudes de devolución.</p><p>Podés consultar la <a href="https://www.argentina.gob.ar/normativa/nacional/638/actualizacion" target="_blank" rel="noopener noreferrer">Ley 24.240 de Defensa del Consumidor </a> y la información oficial sobre <a href="https://www.argentina.gob.ar/justicia/derechofacil/leysimple/boton-arrepentimiento" target="_blank" rel="noopener noreferrer">compras a distancia y arrepentimiento </a>.</p>`,
    ],
    [
      'cambios',
      '07. Actualizaciones y privacidad',
      `<p>Este borrador podrá actualizarse para reflejar el servicio que efectivamente se ofrezca. Los cambios de la presentación no constituyen una aceptación de condiciones comerciales por parte de quien navega. La contratación futura deberá contar con condiciones identificadas y accesibles antes de pagar.</p><p>El tratamiento de datos de esta versión se describe en la <a href="privacidad.html">Política de privacidad</a>. Antes del lanzamiento se revisarán ambos documentos con los datos y procesos reales del prestador.</p>`,
    ],
  ],
);

export const privacy_content = legal_page(
  'Política de privacidad',
  'Esta página describe los datos que utiliza la presentación actual y lo que habrá que informar antes de habilitar el campus.',
  [
    [
      'responsable',
      '01. Alcance y responsable',
      `<p>Esta política se refiere a la presentación de Método Judicial. El campus comercial, el registro público y los pagos todavía no están habilitados. Existe un campus de prueba local para el equipo, con cuenta entregada manualmente. La identificación del responsable y un canal público para consultas y ejercicio de derechos se incorporarán antes de habilitar inscripciones o la recopilación de datos de estudiantes.</p><p>No se presentan datos de contacto ficticios ni se afirma que la futura plataforma ya tenga implementados controles o certificaciones que no fueron verificados.</p>`,
    ],
    [
      'datos',
      '02. Datos en esta presentación',
      `<p>La página no tiene registro de estudiantes ni formulario de contacto, no solicita DNI ni comprobantes de pago y el ingreso de prueba transmite el código de acceso únicamente al servidor local para validar la cuenta habilitada.</p><p>En la prueba local, el código se verifica por su huella SHA-256; no se guarda en los scripts públicos. El servidor utiliza una cookie de sesión HttpOnly y SameSite=Strict, con vencimiento por inactividad a los 30 minutos y máximo de 2 horas. Se guardan el identificador interno del acceso habilitado, resultados y logros de la prueba en una base local fuera del sitio. Los intentos de ingreso fallidos se registran durante la ventana de bloqueo de 15 minutos. Los resultados se conservan hasta que el equipo elimine los datos de prueba. La transcripción de mecanografía no se conserva en el historial; se guardan sus métricas. Usá solo las códigos de demostración. Las funciones de autocompletar del navegador tienen sus ajustes separados.</p><p>Al solicitar una página, el servidor que la entrega recibe información técnica de la conexión, que puede incluir dirección IP, ruta solicitada, fecha y datos del navegador. El servidor local de prueba no registra cuerpos, códigos ni cookies en la consola. Las condiciones del proveedor de alojamiento deberán informarse al publicar.</p>`,
    ],
    [
      'cookies',
      '03. Cookies y servicios externos',
      `<p>La presentación pública no incorpora cookies de seguimiento, analítica ni píxeles publicitarios. El campus local usa una cookie necesaria para mantener la sesión; no se utiliza con fines publicitarios. Las imágenes, estilos, iconos y scripts se sirven desde el propio sitio. No hay contenido incrustado de redes sociales.</p><p>Los enlaces a fuentes oficiales son enlaces externos. Esos sitios reciben la conexión cuando decidís visitarlos y aplican sus propias políticas. Su contenido no se carga automáticamente dentro de esta página.</p>`,
    ],
    [
      'futuro',
      '04. Antes de habilitar el campus',
      `<p>El servicio futuro necesitará informar qué datos se solicitarán para crear la cuenta, verificar el pago, prestar soporte y registrar el progreso; su finalidad y fundamento; qué datos serán obligatorios; los destinatarios y proveedores; y los plazos de conservación o sus criterios.</p><p>También deberá informar cualquier almacenamiento o transferencia internacional que corresponda. Esta presentación no autoriza de forma anticipada esos tratamientos ni suscripciones comerciales. No hay un plazo de conservación del campus definido porque todavía el servicio comercial aún no está operativo.</p>`,
    ],
    [
      'derechos',
      '05. Tus derechos',
      `<p>La Ley 25.326 reconoce derechos de información, acceso, rectificación, actualización y supresión de datos personales, en los términos que correspondan. El canal del responsable para ejercerlos deberá estar disponible antes de recopilar datos de estudiantes.</p><p>Podés consultar la <a href="https://www.argentina.gob.ar/aaip/datospersonales/derechos" target="_blank" rel="noopener noreferrer">guía de derechos de la Agencia de Acceso a la Información Pública (AAIP) </a>, incluida la orientación para presentar denuncias, y el <a href="https://www.argentina.gob.ar/normativa/nacional/ley-25326-64790/actualizacion" target="_blank" rel="noopener noreferrer">texto de la Ley 25.326 </a>.</p>`,
    ],
    [
      'actualizaciones',
      '06. Actualizaciones',
      `<p>La fecha de esta página identifica la versión del borrador. Antes de abrir el campus se actualizará la política para reflejar el funcionamiento real y se informarán los cambios pertinentes. La mera navegación por la presentación no se utiliza como consentimiento para fines adicionales.</p><p>Consultá también los <a href="terminos.html">Términos y condiciones</a> para conocer el alcance de la propuesta.</p>`,
    ],
  ],
);
