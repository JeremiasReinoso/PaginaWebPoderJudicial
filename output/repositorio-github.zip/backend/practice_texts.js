/** Original fictional training texts. Not official documents or legal advice. */

export const TEXTS = [
  {
    id: 'organizacion',
    title: 'Organizar el trabajo sin perder de vista a las personas',
    topic: 'Organización institucional',
    text: `Al comenzar una semana de trabajo, un equipo de atención revisó las consultas que habían quedado sin respuesta. La primera propuesta consistió en repartirlas por orden de llegada y pedir que cada agente resolviera la mayor cantidad posible. Sin embargo, antes de aplicar esa medida, el grupo examinó una muestra de los registros. Descubrió que algunas consultas estaban duplicadas, otras habían sido dirigidas a una oficina que no intervenía en el asunto y varias carecían de información suficiente para determinar el siguiente paso.

El hallazgo cambió la manera de organizar la tarea. En lugar de medir únicamente cuántas respuestas salían por día, el equipo decidió distinguir entre recibir una consulta, identificar su objeto y orientar a la persona. Esas acciones estaban relacionadas, pero no eran equivalentes. Registrar rápidamente un pedido podía mejorar una cifra sin acercar a quien consultaba a una solución. Del mismo modo, responder con una fórmula general podía cerrar un registro y, al mismo tiempo, provocar una nueva consulta por falta de claridad.

Para ordenar el trabajo, se elaboró una guía interna con tres preguntas: qué necesita la persona, qué información falta y qué sector tiene atribuciones para continuar. La guía no habilitaba a cualquier agente a decidir sobre cualquier asunto. Su finalidad era reconocer los límites de cada función y facilitar una derivación fundada. Cuando existían dudas sobre la competencia de un sector, correspondía verificarla antes de ofrecer una respuesta definitiva. También se acordó dejar constancia de la orientación brindada, evitando incorporar datos personales que no fueran necesarios.

La evaluación de la experiencia se realizó al finalizar el mes. El número de respuestas no había aumentado de manera espectacular, pero se habían reducido las derivaciones equivocadas y las consultas repetidas por instrucciones incompletas. Además, los registros permitían identificar con mayor precisión dónde se producían las demoras. Esa información era más útil para mejorar el servicio que una cifra aislada de trámites cerrados.

El equipo concluyó que organizar no consiste solamente en distribuir tareas. También exige comprender la finalidad de cada actividad, reconocer responsabilidades y revisar sus efectos. La rapidez conserva su importancia, pero necesita acompañarse de información correcta y de un recorrido comprensible para la persona. La experiencia mostró que una mejora modesta en los indicadores de volumen puede convivir con un avance significativo en la calidad de la atención. Ninguna cifra, considerada por separado, permite describir todo el funcionamiento de un servicio.`,
    questions: [
      [
        '¿Cuál fue el problema de la propuesta inicial?',
        [
          'Priorizaba el volumen sin examinar la naturaleza de las consultas',
          'Exigía revisar demasiados indicadores de calidad',
          'Impedía registrar pedidos',
          'Prohibía las derivaciones',
        ],
        0,
        'La revisión encontró duplicados y errores que un simple reparto por cantidad no resolvía.',
      ],
      [
        '¿Qué función cumplía la guía interna?',
        [
          'Otorgar nuevas atribuciones judiciales',
          'Identificar necesidades, información faltante y sector competente',
          'Sustituir todas las normas de organización',
          'Eliminar los registros de atención',
        ],
        1,
        'Las tres preguntas orientaban el trabajo sin ampliar las competencias de los agentes.',
      ],
      [
        '¿Qué se puede inferir del resultado del mes?',
        [
          'Toda reducción de volumen indica un fracaso',
          'La rapidez dejó de tener importancia',
          'La calidad puede mejorar sin un gran aumento de respuestas',
          'Las estadísticas ya no aportan información',
        ],
        2,
        'Bajaron errores y repeticiones aunque el volumen no creció de forma espectacular.',
      ],
      [
        '¿Cuál es la idea central del texto?',
        [
          'Cerrar registros es el único objetivo',
          'Todas las oficinas tienen iguales funciones',
          'La atención depende solo de la buena voluntad',
          'La organización debe relacionar tareas, responsabilidades y efectos sobre las personas',
        ],
        3,
        'La conclusión integra finalidad, responsabilidades, claridad y evaluación del servicio.',
      ],
    ],
  },
  {
    id: 'comunicacion',
    title: 'Una explicación que permite continuar',
    topic: 'Atención y lenguaje claro',
    text: `Una persona llegó a una oficina después de recibir un mensaje que le pedía completar documentación. Había leído la comunicación varias veces, pero no sabía si debía presentar originales, enviar copias o solicitar una entrevista. En la recepción explicó que temía perder tiempo y volver a su casa sin haber realizado el trámite. La agente que la atendió advirtió que repetir las mismas palabras del mensaje no resolvería la dificultad: el problema no era la falta de lectura, sino la ausencia de instrucciones comprensibles.

La agente comenzó por preguntar qué parte de la comunicación generaba dudas. Escuchó la respuesta completa y reformuló lo que había entendido. Así pudo distinguir dos necesidades: conocer qué documentos faltaban y saber por qué canal debían presentarse. Antes de responder, verificó la información disponible y consultó al sector responsable sobre un requisito que no estaba claro. Esa consulta evitó ofrecer una indicación segura en apariencia, pero posiblemente incorrecta. Reconocer un límite de conocimiento no significaba abandonar la atención, sino buscar una respuesta confiable.

Una vez confirmados los datos, organizó la explicación en pasos breves. Indicó primero la documentación necesaria; después, el medio de presentación; finalmente, la forma de consultar el estado del pedido. Explicó los términos técnicos que no podían omitirse y entregó una guía escrita con la misma secuencia. No prometió que el trámite tendría un resultado favorable ni que se resolvería antes de una fecha determinada, porque ninguna de esas decisiones dependía de ella.

Antes de finalizar, pidió a la persona que contara con sus propias palabras qué haría al salir de la oficina. La respuesta permitió advertir una confusión que todavía persistía sobre el canal de presentación. La agente volvió sobre ese punto y lo aclaró con un ejemplo. Si se hubiera limitado a preguntar si todo estaba entendido, probablemente habría recibido una respuesta afirmativa y la dificultad habría permanecido oculta.

Al revisar la experiencia, el equipo distinguió entre brindar mucha información y brindar información útil. La claridad no exigía suprimir todos los detalles, sino seleccionar los pertinentes, ordenarlos y comprobar su comprensión. La escucha había permitido identificar el problema real; la verificación había sostenido la precisión; la explicación por pasos había facilitado la acción. El valor de la atención no residió en hablar más, sino en que la persona pudiera continuar con un próximo paso concreto, sin falsas garantías y con un canal de consulta disponible.`,
    questions: [
      [
        '¿Cuál era la dificultad principal de la persona?',
        [
          'Se negaba a leer el mensaje',
          'No comprendía cómo cumplir las instrucciones',
          'No quería presentar documentación',
          'Ya había completado todos los requisitos',
        ],
        1,
        'El texto distingue expresamente la falta de comprensión de la falta de lectura.',
      ],
      [
        '¿Por qué la agente consultó al sector responsable?',
        [
          'Para evitar escuchar a la persona',
          'Para garantizar un resultado favorable',
          'Para verificar un requisito antes de informar',
          'Para cancelar la atención',
        ],
        2,
        'Buscó precisión frente a una duda en lugar de improvisar una respuesta.',
      ],
      [
        '¿Qué permitió detectar la confusión restante?',
        [
          'Entregar más formularios',
          'Repetir una fórmula técnica',
          'Prometer una fecha de resolución',
          'Pedir que la persona explicara los pasos con sus palabras',
        ],
        3,
        'La reformulación de la persona reveló la duda sobre el canal de presentación.',
      ],
      [
        '¿Qué conclusión sostiene el texto?',
        [
          'La información útil combina precisión, orden y comprobación de comprensión',
          'La claridad requiere eliminar todos los detalles',
          'Una respuesta extensa siempre es mejor',
          'La atención debe asegurar decisiones favorables',
        ],
        0,
        'La conclusión relaciona escucha, verificación, explicación y posibilidad de actuar.',
      ],
    ],
  },
  {
    id: 'accesibilidad',
    title: 'Dos maneras de mejorar el mismo recorrido',
    topic: 'Derechos y accesibilidad',
    text: `En un espacio de formación se propuso analizar el recorrido de una persona que intentaba realizar una consulta institucional. La entrada del edificio contaba con una rampa, pero la información sobre turnos solo estaba disponible en un cartel con letra pequeña. A su vez, el formulario digital utilizaba instrucciones extensas y, cuando faltaba un dato, mostraba un mensaje de error que no explicaba cómo corregirlo. El ejemplo permitió advertir que una mejora física, aunque necesaria, no bastaba para volver accesible todo el servicio.

El grupo organizó los obstáculos en varias dimensiones. Algunos correspondían al entorno material; otros, a la comunicación o a las herramientas tecnológicas. También identificó barreras actitudinales: suponer que una persona no comprendería por su edad, hablar únicamente con quien la acompañaba o imponer ayuda sin preguntarle. Estas conductas podían dificultar la participación incluso cuando el edificio y el sistema digital funcionaban correctamente. La accesibilidad debía examinarse como una relación entre las personas y las condiciones concretas del entorno.

A partir de ese diagnóstico se discutieron dos líneas de trabajo. La primera consistía en revisar el diseño habitual del servicio: mejorar la señalización, redactar instrucciones claras, ofrecer formatos legibles y probar los formularios con distintas necesidades de uso. La segunda atendía situaciones particulares que requerían una adaptación específica. Por ejemplo, podía resultar necesario ofrecer otro canal de comunicación o disponer de un apoyo para una persona determinada. La existencia de un diseño general más accesible no eliminaba todas las necesidades individuales.

Durante el debate surgió una propuesta de crear un circuito separado para cualquier persona que pareciera necesitar ayuda. El grupo la cuestionó porque se basaba en apariencias y podía limitar innecesariamente la autonomía. En cambio, propuso consultar qué apoyo se requería, dirigirse a la persona interesada y permitir que participara en las decisiones sobre su propio recorrido. La respuesta debía ajustarse a una necesidad reconocida, no a una presunción sobre sus capacidades.

La conclusión fue que el acceso efectivo necesita combinar previsión y flexibilidad. Prever significa reducir obstáculos desde la organización ordinaria del servicio. Ser flexible implica reconocer que pueden aparecer situaciones que ese diseño no haya resuelto. Ambas estrategias se complementan y requieren evaluación: no alcanza con declarar que un canal es accesible si quienes lo utilizan no pueden completar la tarea. Escuchar la experiencia de las personas permite descubrir barreras que una revisión exclusivamente interna puede dejar inadvertidas.`,
    questions: [
      [
        '¿Qué muestra el ejemplo de la rampa y el formulario?',
        [
          'La accesibilidad depende únicamente del edificio',
          'Las herramientas digitales siempre eliminan las barreras',
          'La accesibilidad comprende varias dimensiones del servicio',
          'La comunicación escrita no influye en el acceso',
        ],
        2,
        'El ejemplo reúne obstáculos físicos, comunicacionales, tecnológicos y actitudinales.',
      ],
      [
        '¿Por qué se cuestionó el circuito separado propuesto?',
        [
          'Porque permitía preguntar qué apoyo era necesario',
          'Porque eliminaba todos los formularios',
          'Porque exigía mejorar la señalización',
          'Porque se basaba en apariencias y podía restringir autonomía',
        ],
        3,
        'El grupo prefirió consultar necesidades en vez de presumir capacidades por la apariencia.',
      ],
      [
        '¿Cómo se relacionan previsión y flexibilidad?',
        [
          'Se complementan: diseño habitual y respuesta a necesidades particulares',
          'Una vuelve innecesaria a la otra',
          'Solo se aplican a edificios nuevos',
          'Son dos nombres para una misma medida',
        ],
        0,
        'El texto diferencia las dos estrategias y explica que deben actuar juntas.',
      ],
      [
        '¿Para qué sirve escuchar a quienes utilizan el servicio?',
        [
          'Para sustituir toda evaluación técnica',
          'Para reconocer barreras que la revisión interna puede omitir',
          'Para prometer que nunca existirán obstáculos',
          'Para asignar capacidades según la edad',
        ],
        1,
        'La experiencia de uso aporta dificultades que pueden no ser visibles desde la institución.',
      ],
    ],
  },
  {
    id: 'perspectiva',
    title: 'Revisar las primeras impresiones',
    topic: 'Perspectiva de género y trato respetuoso',
    text: `En una actividad de capacitación, un grupo recibió la descripción de una entrevista ficticia. Una persona había realizado una consulta y luego había cambiado parte de su relato. Algunos participantes interpretaron ese cambio como prueba suficiente de que la consulta no era seria. Otros propusieron detenerse antes de llegar a una conclusión y revisar qué información faltaba. La coordinadora aclaró que el ejercicio no buscaba decidir un caso, sino examinar cómo las primeras impresiones pueden influir en la atención y en la lectura de un registro.

El grupo volvió entonces sobre la descripción. No sabía en qué condiciones se había desarrollado la primera conversación, si la persona había comprendido las preguntas o si existían temores que dificultaran hablar. Tampoco contaba con otros elementos que permitieran explicar el cambio. Reconocer esas ausencias no obligaba a aceptar una única hipótesis; exigía evitar que una interpretación inicial se presentara como un hecho demostrado. La diferencia entre describir una conducta y atribuirle un significado definitivo se volvió central para el análisis.

Después se trabajó sobre los estereotipos. Una expectativa acerca de cómo debería hablar, vestirse o reaccionar alguien podía convertirse en un criterio implícito para evaluar su credibilidad. El problema no era observar lo que ocurría en la entrevista, sino utilizar un modelo rígido de comportamiento para descartar experiencias diferentes. El equipo también consideró que las dificultades económicas, el idioma, la edad y las relaciones de dependencia podían combinarse e influir en la posibilidad de pedir ayuda. Ningún factor aislado describía por completo la situación de una persona.

Como parte de la revisión, se propusieron prácticas de atención: explicar el propósito de las preguntas, evitar repeticiones innecesarias del relato, cuidar la privacidad y registrar de manera precisa qué se había dicho. También se destacó la importancia de conocer los canales institucionales disponibles y de actuar dentro de las propias atribuciones. Escuchar respetuosamente no significaba anticipar una decisión, reemplazar una investigación o asegurar un resultado. Significaba crear condiciones adecuadas para que la consulta pudiera ser comprendida y encaminada.

Al finalizar, los participantes reformularon su primera respuesta. En lugar de afirmar que el cambio de relato demostraba por sí mismo una intención, señalaron que necesitaban contexto y elementos adicionales. El aprendizaje no consistió en reemplazar un prejuicio por una certeza opuesta, sino en reconocer la incertidumbre y mejorar el método de análisis. Revisar estereotipos permite formular mejores preguntas, distinguir datos de inferencias y reducir daños que pueden surgir de una respuesta institucional apresurada.`,
    questions: [
      [
        '¿Cuál era el objetivo de la capacitación?',
        [
          'Examinar la influencia de las primeras impresiones en la atención',
          'Resolver definitivamente un caso real',
          'Establecer una única reacción válida',
          'Sustituir los canales institucionales',
        ],
        0,
        'La coordinadora diferencia el análisis de prácticas de la decisión de un caso.',
      ],
      [
        '¿Qué diferencia destaca el segundo párrafo?',
        [
          'Entre entrevistar y registrar, actividades incompatibles',
          'Entre describir una conducta y atribuirle un significado definitivo',
          'Entre privacidad y atención, objetivos opuestos',
          'Entre un dato completo y una sentencia',
        ],
        1,
        'El cambio observado no demostraba por sí solo la explicación que se le atribuía.',
      ],
      [
        '¿Qué función cumple considerar factores combinados?',
        [
          'Reducir todas las experiencias a una causa',
          'Establecer credibilidad por apariencia',
          'Comprender que varias condiciones pueden influir en pedir ayuda',
          'Evitar formular preguntas',
        ],
        2,
        'El texto relaciona distintas condiciones sin convertir una en explicación total.',
      ],
      [
        '¿Qué cambió al final de la actividad?',
        [
          'Se adoptó la certeza opuesta sin examinarla',
          'Se decidió ignorar todo registro',
          'Se garantizó un resultado favorable',
          'Se reconoció la necesidad de contexto y elementos adicionales',
        ],
        3,
        'La conclusión sustituye el juicio apresurado por un análisis que reconoce incertidumbre.',
      ],
    ],
  },
  {
    id: 'estudio',
    title: 'Leer, comparar y comprobar lo aprendido',
    topic: 'Método de estudio e integración',
    text: `Una estudiante preparaba cinco módulos para una evaluación. Durante los primeros días subrayaba casi todos los párrafos y repetía las definiciones hasta poder reconocerlas al verlas escritas. Esa familiaridad le daba confianza, pero al resolver ejercicios encontraba dificultades para distinguir conceptos próximos. Podía recordar una frase y, aun así, no explicar por qué una opción era más adecuada que otra. Decidió entonces revisar su forma de estudiar, sin abandonar la lectura de los documentos completos.

En la siguiente etapa comenzó cada tema con una lectura orientada a comprender su estructura. Identificaba la pregunta principal, los conceptos necesarios para responderla y las relaciones entre ellos. Después elaboraba un resumen con sus propias palabras. Si no podía explicar una idea sin copiar el párrafo, volvía a la fuente y buscaba qué parte no había entendido. El resumen no se utilizaba como sustituto automático del material, sino como una herramienta para comprobar comprensión y organizar el repaso posterior.

Para los conceptos que confundía, preparó cuadros comparativos. En cada fila anotaba las nociones que necesitaba diferenciar y elegía criterios comunes: función, alcance, participantes o finalidad. Esa decisión era importante, porque una comparación pierde utilidad cuando cada columna responde a una pregunta distinta. También dibujaba mapas conceptuales para mostrar relaciones más amplias entre los temas. El cuadro ayudaba a distinguir; el mapa, a conectar. Ambos recursos eran complementarios y podían corregirse a medida que avanzaba la lectura.

Al terminar una unidad, respondía preguntas sin consultar sus apuntes. Luego revisaba no solo los errores, sino también las respuestas correctas que había elegido por descarte o con dudas. Anotaba el motivo de la dificultad: confusión de términos, lectura apresurada, olvido de una excepción o falta de comprensión. De ese modo, la puntuación se convertía en información para planificar la próxima sesión. Repetir de inmediato el mismo ejercicio podía mejorar el resultado por memoria de las opciones, sin demostrar necesariamente una comprensión más sólida.

Con el tiempo incorporó repasos que relacionaban los cinco módulos. Un caso de atención podía exigir reconocer una función institucional, identificar una barrera y explicar un próximo paso de manera clara. Estas conexiones le permitían evitar que cada unidad quedara aislada. Su objetivo no era memorizar un recorrido único para cualquier situación, sino disponer de criterios para analizar preguntas diferentes. La experiencia le mostró que estudiar implica alternar lectura, elaboración y recuperación activa, y utilizar los resultados para decidir qué necesita volver a trabajar.`,
    questions: [
      [
        '¿Qué limitación tenía la estrategia inicial?',
        [
          'Impedía reconocer palabras escritas',
          'Generaba familiaridad sin asegurar diferenciación de conceptos',
          'Prohibía leer documentos completos',
          'Evitaba cualquier ejercicio',
        ],
        1,
        'Reconocer una definición no le permitía siempre justificar una elección.',
      ],
      [
        '¿Por qué conviene usar criterios comunes en un cuadro?',
        [
          'Para que todas las ideas sean iguales',
          'Para reemplazar el material original',
          'Para comparar las nociones sobre una misma base',
          'Para eliminar las diferencias',
        ],
        2,
        'Si las columnas responden a preguntas distintas, la comparación pierde utilidad.',
      ],
      [
        '¿Por qué revisaba algunas respuestas correctas?',
        [
          'Porque toda respuesta correcta es inválida',
          'Para modificar la puntuación',
          'Para evitar próximos repasos',
          'Porque podían haberse elegido con dudas o por descarte',
        ],
        3,
        'El texto diferencia acertar de comprender con seguridad.',
      ],
      [
        '¿Cuál es el papel de la puntuación en el método?',
        [
          'Aportar información para decidir qué volver a trabajar',
          'Reemplazar toda lectura',
          'Demostrar por sí sola comprensión definitiva',
          'Indicar que nunca debe repetirse un tema',
        ],
        0,
        'La estudiante analiza resultados y motivos de dificultad para planificar el estudio.',
      ],
    ],
  },
];

export const READING_QUESTIONS = {};
for (const item of TEXTS) {
  item.questionIds = [];
  item.questions.forEach(([question, options, correct, explanation], index) => {
    const key = `read-${item.id}-${index}`;
    item.questionIds.push(key);
    READING_QUESTIONS[key] = {
      id: key,
      module: 0,
      question,
      options,
      correct,
      explanation,
    };
  });
}

export function selectNextText(remainingInput, last, choose) {
  const ids = TEXTS.map((item) => item.id);
  let remaining = (remainingInput || []).filter((key) => ids.includes(key));
  if (remaining.length === 0) remaining = [...ids];
  let candidates = remaining.filter((key) => key !== last);
  if (candidates.length === 0) candidates = remaining;
  const selected = choose(candidates);
  const nextRemaining = remaining.filter((key) => key !== selected);
  const chosenText = TEXTS.find((item) => item.id === selected);
  return { chosenText, nextRemaining, selected };
}

/** Draw without replacement per principal and tool; avoid cycle-boundary repeats. */
export function draw_text(db, username, mode, choose) {
  const row = db
    .prepare(
      'SELECT remaining, last FROM text_rotation WHERE username = ? AND mode = ?',
    )
    .get(username, mode);
  const remainingInput = row ? JSON.parse(row.remaining) : [];
  const last = row ? row.last : null;
  const { chosenText, nextRemaining, selected } = selectNextText(
    remainingInput,
    last,
    choose,
  );
  db.prepare(
    `INSERT INTO text_rotation(username, mode, remaining, last) VALUES(?, ?, ?, ?)
     ON CONFLICT(username, mode) DO UPDATE SET remaining = excluded.remaining, last = excluded.last`,
  ).run(username, mode, JSON.stringify(nextRemaining), selected);
  return chosenText;
}
