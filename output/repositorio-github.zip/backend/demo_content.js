/** Original introductory practice examples. Not official or a paid exam bank. */

export const MODULES = [
  'Organización del Estado',
  'El Poder Judicial de Mendoza',
  'Derechos Humanos',
  'Violencia de Género',
  'Atención para un Servicio de Justicia',
];

export const ROWS = [
  [
    1,
    '¿Qué conjunto reúne elementos del Estado?',
    [
      'Territorio, población, poder y gobierno',
      'Edificios, vehículos y oficinas',
      'Solo territorio y gobierno',
      'Solo población y normas',
    ],
    0,
    'El material introductorio identifica territorio, población, poder y gobierno.',
  ],
  [
    1,
    '¿Qué representa el territorio de un Estado?',
    [
      'Su lista de autoridades',
      'El espacio geográfico donde ejerce soberanía',
      'Una reunión de ciudadanos',
      'Un procedimiento judicial',
    ],
    1,
    'El territorio es el espacio geográfico en el que el Estado ejerce su soberanía.',
  ],
  [
    1,
    '¿Qué distingue a un Estado de Derecho?',
    [
      'La ausencia de normas',
      'La concentración sin límites de toda autoridad',
      'Un ordenamiento que regula al gobierno y reconoce derechos',
      'La eliminación de los derechos individuales',
    ],
    2,
    'El Estado de Derecho somete la organización y el funcionamiento del gobierno a un ordenamiento jurídico.',
  ],
  [
    1,
    '¿Cuál es la función de una Constitución?',
    [
      'Reemplazar toda norma de procedimiento',
      'Organizar únicamente una oficina',
      'Regular solo contratos privados',
      'Establecer las bases fundamentales de la organización del Estado',
    ],
    3,
    'La Constitución es la norma fundamental de la organización estatal.',
  ],
  [
    2,
    '¿Para qué sirve especializar juzgados y tribunales por materia?',
    [
      'Para organizar el tratamiento de distintos tipos de conflictos',
      'Para eliminar los procedimientos',
      'Para evitar toda decisión judicial',
      'Para reemplazar al Poder Legislativo',
    ],
    0,
    'Los fueros agrupan la actividad jurisdiccional por materia.',
  ],
  [
    2,
    'En la explicación introductoria del proceso judicial, ¿qué caracteriza al tercero que decide el conflicto?',
    [
      'Representa necesariamente a ambas partes',
      'Debe actuar con imparcialidad',
      'Decide por sorteo sin reglas',
      'Carece de función en el conflicto',
    ],
    1,
    'El proceso se presenta como una vía de resolución ante un tercero imparcial.',
  ],
  [
    2,
    '¿Qué poder sanciona los códigos procesales según la introducción del módulo?',
    [
      'Poder Ejecutivo',
      'Cada parte del proceso',
      'Poder Legislativo',
      'Un proveedor privado',
    ],
    2,
    'La introducción señala que los códigos procesales son sancionados por el Poder Legislativo.',
  ],
  [
    2,
    '¿Cuál de estas expresiones nombra un fuero incluido en el módulo?',
    [
      'Fuero de publicidad',
      'Fuero de ventas',
      'Fuero de transporte turístico',
      'Fuero Civil, Comercial y Tributario',
    ],
    3,
    'El material desarrolla, entre otros, el fuero Civil, Comercial y Tributario.',
  ],
  [
    3,
    '¿Qué idea funda la noción de derechos humanos presentada en el material?',
    [
      'La dignidad de las personas',
      'La preferencia por un grupo social',
      'La supresión de garantías',
      'La utilidad económica exclusiva',
    ],
    0,
    'La dignidad de las personas es un principio fundante de los derechos humanos.',
  ],
  [
    3,
    'En la relación Estado-persona, ¿qué papel se destaca para el Estado?',
    [
      'Vendedor de los derechos',
      'Principal garante de los derechos',
      'Titular exclusivo de todos los derechos personales',
      'Observador sin obligaciones',
    ],
    1,
    'El material presenta al Estado como principal garante y a la persona como titular de derechos.',
  ],
  [
    3,
    '¿Cómo se describen los derechos humanos en la introducción?',
    [
      'Solo como un listado sin historia',
      'Como una cuestión exclusivamente privada',
      'Como construcciones sociales con una historia de luchas y aportes',
      'Como derechos reservados a funcionarios',
    ],
    2,
    'Su comprensión incluye el proceso histórico y social, además de los instrumentos normativos.',
  ],
  [
    3,
    '¿Para qué sirve promover una cultura de derechos humanos en la justicia?',
    [
      'Para eliminar toda garantía',
      'Para reemplazar el trato digno por formalidades',
      'Para limitar el acceso a un grupo',
      'Para orientar la actividad judicial hacia el respeto de los derechos',
    ],
    3,
    'El conocimiento de principios y estándares busca favorecer su aplicación cotidiana.',
  ],
  [
    4,
    '¿Qué permite analizar la perspectiva de género?',
    [
      'Desigualdades y relaciones de poder asociadas al género',
      'Solo diferencias en horarios de trabajo',
      'Exclusivamente expedientes contables',
      'Únicamente datos geográficos',
    ],
    0,
    'Es una herramienta de análisis de las relaciones y desigualdades vinculadas con el género.',
  ],
  [
    4,
    '¿Qué significa transversalizar la perspectiva de género?',
    [
      'Aplicarla únicamente en una charla',
      'Integrarla en políticas, decisiones y prácticas institucionales',
      'Excluirla de las decisiones',
      'Reducirla a una actividad optativa sin relación con el trabajo',
    ],
    1,
    'La transversalización supone integrar esta perspectiva en distintas prácticas y decisiones.',
  ],
  [
    4,
    '¿Qué reconoce un enfoque interseccional?',
    [
      'Que todas las experiencias son idénticas',
      'Que el género nunca se relaciona con otras desigualdades',
      'Que pueden entrelazarse distintos ejes de desigualdad y vulnerabilidad',
      'Que solo importa un aspecto de la persona',
    ],
    2,
    'La interseccionalidad considera cómo se relacionan distintos factores de desigualdad.',
  ],
  [
    4,
    '¿Qué actitud es compatible con una práctica institucional con perspectiva de género?',
    [
      'Reproducir estereotipos sin revisarlos',
      'Ignorar asimetrías de poder',
      'Tratar toda desigualdad como un problema inexistente',
      'Revisar estereotipos y considerar desigualdades relevantes',
    ],
    3,
    'La perspectiva de género requiere una mirada crítica sobre estereotipos y desigualdades.',
  ],
  [
    5,
    '¿Qué ubica en el centro un servicio judicial orientado a la ciudadanía?',
    [
      'Las necesidades, expectativas y derechos de las personas',
      'Solo la comodidad interna',
      'Únicamente los formularios',
      'La rapidez aunque se niegue información',
    ],
    0,
    'El enfoque centra las operaciones y decisiones en las personas y sus derechos.',
  ],
  [
    5,
    '¿Qué práctica ayuda a que una persona comprenda una comunicación judicial?',
    [
      'Agregar tecnicismos inneniejszych'.replace('inneniejszych', 'innecesarios'),
      'Explicar con claridad y lenguaje comprensible',
      'Evitar todas las preguntas',
      'Dar instrucciones contradictorias',
    ],
    1,
    'La claridad de las comunicaciones contribuye al acceso efectivo a la justicia.',
  ],
  [
    5,
    '¿Dónde comienza a construirse un trato digno en el servicio de justicia?',
    [
      'Solo al terminar un expediente',
      'Solo en el archivo',
      'Desde la atención y las interacciones cotidianas',
      'Únicamente fuera de la institución',
    ],
    2,
    'El material destaca las interacciones de atención y las comunicaciones, además de las decisiones.',
  ],
  [
    5,
    '¿Cuál de estas situaciones constituye una barrera para acceder a la justicia?',
    [
      'Recibir una explicación clara',
      'Poder formular una consulta',
      'Ser orientado sobre un trámite',
      'No comprender la información necesaria para realizar un trámite',
    ],
    3,
    'El lenguaje incomprensible puede dificultar el acceso de la ciudadanía a sus derechos.',
  ],
];

export const QUESTIONS = Object.fromEntries(
  ROWS.map(([module, question, options, correct, explanation], i) => {
    const id = `m${module}-${i}`;
    return [id, { id, module, question, options, correct, explanation }];
  }),
);

// Fallback only for typing attempts created before assigned-text snapshots.
export const TYPING_TEXT =
  'El acceso a la justicia comienza con una atención clara y respetuosa. Escuchar la consulta, explicar los pasos y verificar que la información se comprenda ayuda a orientar a cada persona. La práctica constante permite escribir con mayor precisión y confianza.';
